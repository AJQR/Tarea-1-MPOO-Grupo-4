//
//  model.swift
//  cm_07
//
//  Created by Alumno on 25/09/24.
//

import Foundation

struct alumno{
    var nombre:String
    var imagen:String 
}


