import UIKit

class Vista2ViewController: UIViewController{
    var recibe: alumno? = nil
    @IBOutlet weak var label:UILabel!
    @IBOutlet weak var circularImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        print(recibe)
        print(recibe)
        //label!.text = recibe!.nombre
        //circularImageView!.image = UIImage(named: recibe!.imagen)
        //makeImageCircular()
        //print(circularImageView)
        if let alumno = recibe {
            label.text = alumno.nombre
            circularImageView.image = UIImage(named: alumno.imagen)
            let newSize: CGFloat = 150
            
            
            circularImageView.frame = CGRect(x: 0, y: 0, width: newSize, height: newSize)
            makeImageCircular()
            circularImageView.center = CGPoint(x: view.center.x, y: 250)
            
        
        }

}
    func makeImageCircular() {
           
        circularImageView.layer.cornerRadius  = circularImageView.frame.size.width / 2
        circularImageView.clipsToBounds = true
        circularImageView.contentMode = .scaleAspectFit
        
        circularImageView.layer.borderColor = UIColor.white.cgColor
        circularImageView.layer.borderWidth = 4
        
        let containerView = UIView(frame: circularImageView.frame)
        containerView.center = circularImageView.center
        
        containerView.layer.cornerRadius = circularImageView.frame.size.width / 2
        containerView.layer.shadowColor = UIColor.blue.cgColor
        containerView.layer.shadowOpacity = 1.0
        containerView.layer.shadowOffset = CGSize.zero
        containerView.layer.shadowRadius = 20
        
        containerView.addSubview(circularImageView)
        view.addSubview(containerView)

             }
    }
